<?php
include "connect.php";

$fullname = $_POST['fullname'];
$email = $_POST['email'];
$password = $_POST['password'];

$sql = "INSERT INTO users (fullname, email, password)
        VALUES ('$fullname', '$email', '$password')";

if (mysqli_query($conn, $sql)) {
    echo "<script>
        alert('Registration successful!');
        window.location.href = '../index.html';
    </script>";
} else {
    echo "Error: " . mysqli_error($conn);
}
?>
