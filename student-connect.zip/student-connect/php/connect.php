<?php
$conn = mysqli_connect("localhost", "root", "", "student_connect");

if (!$conn) {
    die("Connection failed");
}
?>
