<?php
include "connect.php";

$sql = "SELECT * FROM announcements ORDER BY date_posted DESC";
$result = mysqli_query($conn, $sql);

$announcements = [];

if ($result) {
    while ($row = mysqli_fetch_assoc($result)) {
        $announcements[] = $row;
    }
}

// Return JSON
header('Content-Type: application/json');
echo json_encode($announcements);
?>
