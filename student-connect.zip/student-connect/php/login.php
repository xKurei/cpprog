<?php
session_start();
include "connect.php";

$email = $_POST['email'];
$password = $_POST['password'];

$sql = "SELECT * FROM users WHERE email='$email' AND password='$password'";
$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) == 1) {
    $_SESSION['user'] = $email;
    header("Location: ../dashboard.html");
} else {
    echo "<script>
        alert('Invalid email or password');
        window.location.href = '../index.html';
    </script>";
}
?>
